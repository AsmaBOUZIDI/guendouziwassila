package package1;

public interface IObjetAnimable extends IObjetDessinable{


}
